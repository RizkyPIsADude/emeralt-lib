Hi hi hello hi
This is my first module ive ever published in npmjs

Im too busy to write anything but im gonna wrote a list of function ive made
So i made this pastebin
https://pastebin.com/DqD2izY6

pass: superidol

I will show the list on here so you guys dont lazy clicking it and waiting to load it is not fun

Added wrote() # console.log() rip off
Added random_int() # Math.random() rip off
Added random_round() # oh this one is generate a random integer round value like random_round(5) it will print random value round 5
Added abs() # absolute value
Added sqrt() # square root