Hi hi hello hi
This is my first module ive ever published in npmjs

So i watched YouTube and found a channel showcasing about "Ruby" lang, i was curious what it was. i checked in,
Then the guy is showcasing it that the lang/pl is a simplicityness pl (like python), Because JavaScript functions is so long, I got inspirated and i just make this,

And im confused what name should i use for, i realized "Ruby" is material, because im a Minecraft nerd. Im using emerald instead,
because im thinking its already module/pkg with that name so, Im replacing the D with T, And im CONFUSED again bc there sooo many modules with that name
after that, im adding lib extension inst. And got CONFUSED again what another extension i should use,

And my brain responded to me: "Cant you just use PL?", for those dont know pl is its my my-made-word so, lol (Progamming Language).
And tadaa, Introducing EmeraltLibPL!!!!
Im not using that name for the InNPMJSName, i just called it emeralt-lib. for fun, i called it "that" thing

for help list of the functions, you can install it first, then in your app, write "const e = require('emeralt-lib')"
Put console.log() then inside it put "e.help"

You should get shorthand property.
Thats it! Bye! If you having issues or suggesting a feature

Feel free to send them! (to npmjs)
Cya later!

Current Version: 1.2.10