module.exports.credits ={

	creator: 'RizkyPDude',

	name: 'EmeraltLibPi',

	inspirator: 'RubyProgammingLanguage',

	reason: 'Why im making this because of the Ruby PLanguage, its language so simplistic and i having problem with js its like not simplistic so i made this'

}



module.exports.help ={

	installation: 'Simply put \'const e = require(\'emeralt-lib\')\' on your code!',

	credits: 'e.credits = use e.wrote() and put that in, it will show/explain off why this created (NOT A FUNCTION)',

	wrote: 'e.wrote() = Its same with console.log() but with simplicitynessly',

	wroteErr: 'e.wroteErr() = Its same with console.error() but with sorta-simplicitylessnesslyless',

	random_int: 'e.random_int() = Its useless tho but just lazy to remove it, its generated random integer less than 1',

	random_round: 'e.random_round() = Generates random integer around value youve put',

	pi: 'e.pi = Its not a function so you can put in on e.wrote(), Its basically prints 3.14159265',

	add: 'e.add() = Adding number, examples: e.add(4,3), prints out 7',

	sub: 'e.sub() = opposite of e.add()/subtracts number',

	time: 'Added in 1.2.11, Times value by value, examples: e.time(2,5) it prints out 10',

	div: 'Added in 1.2.11, Division. e.div()',

	sqrt: 'e.sqrt() = Squareroot',

	currentVersion: '1.3.0 (itsBeta: false)',    

	thanks: 'Thanks for installing this silly module/pkg, I just want to make a creative things, if you want suggest some feature. check our GITRepo! -RizkyPDude',
	changelog: '1.3.0-Release: Added e.wroteErr(), Added changelog help, Changed e.dec() to e.sub(), Added e.nan, Added e.pow(), Added nothing '

}



module.exports.wrote =

	function (txt) {

		console.log(txt)

}



module.exports.wroteErr =

	function (err) {

		console.error(err)

}



module.exports.random_int =

	function () {

		console.log(Math.random())

}



module.exports.random_round =

	function (int) {

		console.log(Math.floor(Math.random()*int))

}



module.exports.pi = 3.14159265
module.exports.nan = NaN


module.exports.add =

	function (int1, int2) {

		console.log(int1 + int2)

}



module.exports.sub =

	function (int1, int2) {

		console.log(int1 - int2)

}



module.exports.time =

	function (int1,int2) {

		console.log(int1 * int2)

}



module.exports.div =

	function (int1, int2) {

		console.log(int1/int2)

}

module.exports.pow =
   function (int1,int2) {
       console.log(Math.pow(int1,int2))
 }


module.exports.sqrt =

	function (int) {

		console.log(Math.sqrt(int))

}