module.exports =
function (num) {
  console.log(Math.sqrt(num));
}