module.exports =
function (num) {
  console.log(Math.abs(num));
}