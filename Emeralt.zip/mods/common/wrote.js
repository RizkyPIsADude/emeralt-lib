module.exports =
function (txt) {
  console.log(txt);
}