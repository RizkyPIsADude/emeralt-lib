module.exports =
function (num) {
  console.log(Math.floor(Math.random() * num));
}