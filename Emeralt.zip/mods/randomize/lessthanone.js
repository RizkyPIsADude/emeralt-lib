module.exports =
function () {
  console.log(Math.random());
}