const random_round = require('./mods/randomize/round'); // RANDOMIZE STUFFS
const random_int = require('./mods/randomize/lessthanone');

const wrote = require('./mods/common/wrote'); // COMMON STUFFS

const sqrt = require('./mods/math/sqrt'); // MATH STUFFS
const abs = require('./mods/math/abs');