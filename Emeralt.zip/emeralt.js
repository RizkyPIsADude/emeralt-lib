module.exports.credits ={
	creator: 'RizkyPDude',
	name: 'EmeraltLibPi',
	inspirator: 'RubyProgammingLanguage',
	reason: 'Why im making this because of the Ruby PLanguage, its language so simplistic and i having problem with js its like not simplistic so i made this'
}

module.exports.wrote =
	function (txt) {
		console.log(txt)
}

module.exports.random_int =
	function () {
		console.log(Math.random())
}

module.exports.random_round =
	function (int) {
		console.log(Math.floor(Math.random()*int))
}

module.exports.pi = 3.14159265

module.exports.add =
	function (int1, int2) {
		console.log(int1 + int2)
}

module.exports.dec =
	function (int1, int2) {
		console.log(int1 - int2)
}

module.exports.sqrt =
	function (int) {
		console.log(Math.sqrt(int))
}